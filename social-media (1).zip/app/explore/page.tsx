import Link from "next/link"
import { Search, Sparkles } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"

export default function ExplorePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 dark:from-gray-900 dark:to-gray-950">
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md dark:bg-gray-950/80 dark:border-gray-800">
        <div className="container flex h-16 items-center px-4 md:px-6">
          <div className="text-xl font-bold bg-gradient-to-r from-pink-500 to-violet-500 text-transparent bg-clip-text">
            Explore
          </div>
          <div className="flex-1 items-center justify-center px-2 ml-4">
            <div className="w-full">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search..." className="pl-8 bg-muted/50" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 md:px-6 md:py-8">
        <Tabs defaultValue="trending" className="w-full">
          <div className="mb-6">
            <TabsList className="inline-flex h-10 items-center justify-center rounded-md bg-white p-1 dark:bg-gray-800">
              <TabsTrigger
                value="trending"
                className="rounded-sm px-3 py-1.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-violet-500 data-[state=active]:text-white data-[state=active]:shadow-sm"
              >
                <Sparkles className="mr-2 h-4 w-4" />
                Trending
              </TabsTrigger>
              <TabsTrigger
                value="videos"
                className="rounded-sm px-3 py-1.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-violet-500 data-[state=active]:text-white data-[state=active]:shadow-sm"
              >
                Videos
              </TabsTrigger>
              <TabsTrigger
                value="photos"
                className="rounded-sm px-3 py-1.5 text-sm font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-violet-500 data-[state=active]:text-white data-[state=active]:shadow-sm"
              >
                Photos
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="trending" className="mt-0">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {Array.from({ length: 12 }).map((_, i) => (
                <Link
                  key={i}
                  href={`/post/${i + 1}`}
                  className="aspect-square bg-muted relative rounded-lg overflow-hidden group"
                >
                  <img
                    src={`/placeholder.svg?height=300&width=300&text=${i + 1}`}
                    alt={`Post ${i + 1}`}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                    <div className="text-white text-sm font-medium">Trending post #{i + 1}</div>
                  </div>
                </Link>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="videos" className="mt-0">
            <div className="grid grid-cols-2 gap-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Link
                  key={i}
                  href={`/video/${i + 1}`}
                  className="aspect-[9/16] bg-muted relative rounded-lg overflow-hidden group"
                >
                  <img
                    src={`/placeholder.svg?height=500&width=280&text=Video+${i + 1}`}
                    alt={`Video ${i + 1}`}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent text-white">
                    <div className="text-sm font-medium">Trending video #{i + 1}</div>
                    <div className="text-xs flex items-center gap-1 mt-1">
                      <span className="h-1 w-1 rounded-full bg-pink-500"></span>
                      1.2M views
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="photos" className="mt-0">
            <div className="grid grid-cols-3 gap-1">
              {Array.from({ length: 15 }).map((_, i) => (
                <Link key={i} href={`/post/${i + 1}`} className="aspect-square bg-muted relative">
                  <img
                    src={`/placeholder.svg?height=300&width=300&text=${i + 1}`}
                    alt={`Post ${i + 1}`}
                    className="w-full h-full object-cover"
                  />
                </Link>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-t dark:bg-gray-950/80 dark:border-gray-800">
        <div className="container flex h-14 items-center justify-around px-4 md:px-6">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-gray-500"
              >
                <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
              <span className="sr-only">Home</span>
            </Link>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-violet-500 hover:text-violet-600 dark:text-violet-400 dark:hover:text-violet-300"
          >
            <Search className="h-6 w-6" />
            <span className="sr-only">Explore</span>
          </Button>
          <Button variant="ghost" size="icon" className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-violet-500 rounded-full opacity-20"></div>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6 text-pink-600 dark:text-pink-400"
            >
              <path d="M5 12h14"></path>
              <path d="M12 5v14"></path>
            </svg>
            <span className="sr-only">Create</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-teal-500 hover:text-teal-600 dark:text-teal-400 dark:hover:text-teal-300"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="h-6 w-6"
            >
              <polygon points="23 7 16 12 23 17 23 7"></polygon>
              <rect x="1" y="5" width="15" height="14" rx="2" ry="2"></rect>
            </svg>
            <span className="sr-only">Reels</span>
          </Button>
          <Button variant="ghost" size="icon" asChild>
            <Link href="/profile">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="h-6 w-6 text-gray-500"
              >
                <circle cx="12" cy="8" r="5"></circle>
                <path d="M20 21a8 8 0 1 0-16 0"></path>
              </svg>
              <span className="sr-only">Profile</span>
            </Link>
          </Button>
        </div>
      </footer>
    </div>
  )
}
