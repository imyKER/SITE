import Link from "next/link"
import { ArrowLeft, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function MessagesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="mr-2">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Link>
          <div className="font-bold text-xl">Messages</div>
          <div className="flex-1" />
          <Button variant="ghost" size="icon">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
        </div>
      </header>
      <main className="flex-1 overflow-auto">
        <div className="container py-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search messages..." className="pl-8" />
          </div>

          <div className="space-y-2">
            {["alex_design", "maria_travels", "tech_guru", "food_lover", "nature_explorer"].map((name, i) => (
              <Link
                key={i}
                href={`/messages/${name}`}
                className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted"
              >
                <Avatar>
                  <AvatarImage src={`/placeholder.svg?height=40&width=40&text=${i + 1}`} alt={name} />
                  <AvatarFallback>{name[0].toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <div className="font-medium truncate">{name}</div>
                    <div className="text-xs text-muted-foreground">2h</div>
                  </div>
                  <div className="text-sm text-muted-foreground truncate">
                    Hey, how are you doing? Let's catch up soon!
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
