import Link from "next/link"
import { ArrowLeft, Phone, Send, Video } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function ChatPage({ params }: { params: { username: string } }) {
  const username = params.username

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/messages" className="mr-2">
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Link>
          <Avatar className="h-8 w-8 mr-2">
            <AvatarImage src={`/placeholder.svg?height=32&width=32&text=${username[0]}`} alt={username} />
            <AvatarFallback>{username[0].toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="font-medium">{username}</div>
          <div className="flex-1" />
          <Button variant="ghost" size="icon">
            <Phone className="h-5 w-5" />
            <span className="sr-only">Call</span>
          </Button>
          <Button variant="ghost" size="icon">
            <Video className="h-5 w-5" />
            <span className="sr-only">Video</span>
          </Button>
        </div>
      </header>
      <main className="flex-1 overflow-auto p-4 space-y-4">
        <div className="flex max-w-[75%] flex-col gap-2 rounded-lg bg-muted p-3 text-sm">Hey! How are you doing?</div>

        <div className="flex max-w-[75%] flex-col gap-2 rounded-lg bg-primary p-3 text-sm text-primary-foreground ml-auto">
          I'm good! Just checking out this new social media app. It's pretty cool!
        </div>

        <div className="flex max-w-[75%] flex-col gap-2 rounded-lg bg-muted p-3 text-sm">
          Yeah, I love how it combines features from different platforms. The messaging is like WhatsApp, but it has
          Instagram-style posts too.
        </div>

        <div className="flex max-w-[75%] flex-col gap-2 rounded-lg bg-primary p-3 text-sm text-primary-foreground ml-auto">
          And the collections feature reminds me of Pinterest! Did you see the short videos section? It's like TikTok.
        </div>

        <div className="flex max-w-[75%] flex-col gap-2 rounded-lg bg-muted p-3 text-sm">
          It's the best of everything! Want to meet up later to talk about it more?
        </div>
      </main>
      <div className="sticky bottom-0 border-t bg-background p-4">
        <div className="flex items-center gap-2">
          <Input placeholder="Type a message..." className="flex-1" />
          <Button size="icon">
            <Send className="h-4 w-4" />
            <span className="sr-only">Send</span>
          </Button>
        </div>
      </div>
    </div>
  )
}
