import Link from "next/link"
import { Search, Heart, MessageCircle, Bookmark, Home, Compass, PlusSquare, Play, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 dark:from-gray-900 dark:to-gray-950">
      <header className="sticky top-0 z-50 w-full border-b bg-white/80 backdrop-blur-md dark:bg-gray-950/80 dark:border-gray-800">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-violet-500 text-transparent bg-clip-text">
              FIXOO
            </span>
          </Link>
          <div className="hidden md:flex md:flex-1 md:items-center md:justify-center px-2">
            <div className="w-full max-w-sm">
              <div className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search..." className="pl-8 bg-muted/50" />
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-pink-500 hover:text-pink-600 dark:text-pink-400 dark:hover:text-pink-300"
            >
              <Heart className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="text-violet-500 hover:text-violet-600 dark:text-violet-400 dark:hover:text-violet-300"
            >
              <MessageCircle className="h-5 w-5" />
              <span className="sr-only">Messages</span>
            </Button>
            <Avatar className="h-8 w-8 border-2 border-pink-500">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
              <AvatarFallback className="bg-gradient-to-br from-pink-500 to-violet-500 text-white">U</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="container px-4 py-6 md:px-6 md:py-8">
        <div className="mb-8 overflow-x-auto pb-2">
          <div className="flex gap-4">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="flex flex-col items-center">
                <div className="h-16 w-16 rounded-full p-0.5 bg-gradient-to-br from-pink-500 to-violet-500">
                  <div className="h-full w-full rounded-full border-2 border-white dark:border-gray-950 overflow-hidden">
                    <img
                      src={`/placeholder.svg?height=64&width=64&text=${i + 1}`}
                      alt={`Story ${i + 1}`}
                      className="h-full w-full object-cover"
                    />
                  </div>
                </div>
                <span className="mt-1 text-xs">user_{i + 1}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6 max-w-xl mx-auto">
          {Array.from({ length: 5 }).map((_, i) => (
            <div
              key={i}
              className="rounded-xl border bg-white shadow-sm dark:bg-gray-900 dark:border-gray-800 overflow-hidden"
            >
              <div className="p-4 flex items-center gap-3">
                <Avatar className="h-8 w-8 border-2 border-pink-500">
                  <AvatarImage src={`/placeholder.svg?height=32&width=32&text=${i + 1}`} alt="User" />
                  <AvatarFallback className="bg-gradient-to-br from-pink-500 to-violet-500 text-white">
                    {i + 1}
                  </AvatarFallback>
                </Avatar>
                <div className="font-medium">user_{i + 1}</div>
              </div>
              <div className="aspect-square bg-muted relative">
                <img
                  src={`/placeholder.svg?height=600&width=600&text=Post+${i + 1}`}
                  alt={`Post ${i + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-pink-500 hover:text-pink-600 dark:text-pink-400 dark:hover:text-pink-300"
                  >
                    <Heart className="h-6 w-6" />
                    <span className="sr-only">Like</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="text-violet-500 hover:text-violet-600 dark:text-violet-400 dark:hover:text-violet-300"
                  >
                    <MessageCircle className="h-6 w-6" />
                    <span className="sr-only">Comment</span>
                  </Button>
                  <div className="ml-auto">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-teal-500 hover:text-teal-600 dark:text-teal-400 dark:hover:text-teal-300"
                    >
                      <Bookmark className="h-6 w-6" />
                      <span className="sr-only">Save</span>
                    </Button>
                  </div>
                </div>
                <div className="text-sm font-medium">1,234 likes</div>
                <div className="text-sm">
                  <span className="font-medium">user_{i + 1}</span> This is a beautiful post with amazing content!
                  <span className="text-pink-500">#fixoo</span> <span className="text-violet-500">#trending</span>
                </div>
                <div className="text-xs text-muted-foreground">View all 87 comments</div>
                <div className="text-xs text-muted-foreground">2 HOURS AGO</div>
              </div>
            </div>
          ))}
        </div>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 z-40 bg-white/80 backdrop-blur-md border-t dark:bg-gray-950/80 dark:border-gray-800">
        <div className="container flex h-14 items-center justify-between px-4 md:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="text-pink-500 hover:text-pink-600 dark:text-pink-400 dark:hover:text-pink-300"
          >
            <Home className="h-6 w-6" />
            <span className="sr-only">Home</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-violet-500 hover:text-violet-600 dark:text-violet-400 dark:hover:text-violet-300"
          >
            <Compass className="h-6 w-6" />
            <span className="sr-only">Explore</span>
          </Button>
          <Button variant="ghost" size="icon" className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-violet-500 rounded-full opacity-20"></div>
            <PlusSquare className="h-6 w-6 text-pink-600 dark:text-pink-400" />
            <span className="sr-only">Create</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-teal-500 hover:text-teal-600 dark:text-teal-400 dark:hover:text-teal-300"
          >
            <Play className="h-6 w-6" />
            <span className="sr-only">Reels</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-gray-500 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-300"
          >
            <User className="h-6 w-6" />
            <span className="sr-only">Profile</span>
          </Button>
        </div>
      </footer>
    </div>
  )
}
