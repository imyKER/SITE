# SITE-WEB

FIXOO - A beautiful social media platform inspired by Instagram and TikTok.

## Features

- Modern, vibrant UI with gradient colors
- Feed page with posts and stories
- Explore page with trending content
- User profiles
- Mobile-first responsive design

## Technologies Used

- Next.js
- React
- Tailwind CSS
- Lucide React icons
- shadcn/ui components

## Getting Started

1. Clone the repository
2. Install dependencies with `npm install`
3. Run the development server with `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Deployment

This project can be deployed to Vercel or any other hosting platform that supports Next.js.
